
package dados.dao;

import dados.dao.Conexao;
import interfac.form.NovoUsuario;
import interfac.form.TelaInicial;
import formulario.model.Usuario;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class usuarioDAO {
    public void inserir(Usuario usuario){
      String sql = "INSERT INTO MAPA (NOME, LOGIN, SENHA, EMAIL) VALUES (?,?,?,?)";
      
      PreparedStatement ps;
      
      try {
              ps = Conexao.getConnection().prepareStatement(sql);
              ps.setString(1, usuario.getNome());
              ps.setString(2, usuario.getLogin());
              ps.setString(3, usuario.getSenha());
              ps.setString(4, usuario.getEmail());
              
              ps.execute();
              
      }catch (SQLException e){
        e.printStackTrace();
        
    }
    
   }
    public boolean autenticar(String login, String senha) {
        String sql = "SELECT * FROM MAPA WHERE LOGIN = ? AND SENHA = ?";
        try {
            Connection conn = Conexao.getConnection().prepareStatement(sql);
            ps.setString(1, login);
            ps.setString(2, senha);
            ResultSet rs = ps.executeQuery();

            // Se houver um resultado no conjunto de resultados, as credenciais são válidas.
            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}

