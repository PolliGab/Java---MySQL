
package br.edu.unicesumar;
import interfac.form.TelaInicial;
import javax.swing.JOptionPane;

public class SistemaMapa {

    public static void main(String[] args) {
        TelaInicial ti = new TelaInicial();
        ti.setVisible(true);
    }
    
}
